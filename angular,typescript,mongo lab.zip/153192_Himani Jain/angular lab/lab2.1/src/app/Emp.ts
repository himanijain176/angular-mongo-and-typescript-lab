export class Emp{
    empId:number;
    empName:string;
    empSal:number;
    empDep:string;

}