import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
public employees=[
                   
                   {"empId":"1001","empName":"Rahul","empSal":"9000","empDep":"Java"},
                   {"empId":"1002","empName":"Sachin","empSal":"19000","empDep":"OraApps"},
                   {"empId":"1003","empName":"Vikash","empSal":"29000","empDep":"BI"},
                   

  ];



public idval:string='';
 public nameval:string='';
 public salval:string='';
public  depval:string;
public i=0;

display(EmpId,EmpName,EmpSal,EmpDep){
    var data ={"empId":EmpId,"empName":EmpName,"empSal":EmpSal,"empDep":EmpDep}
    this.employees.push(data);
    alert(EmpId+" "+EmpName+" "+EmpSal+" "+EmpDep);
  }

update_detail(EmpId:string)
{
  var x=0;
    for(var emp of this.employees){
      if(emp.empId==EmpId){
          this.idval = emp.empId;
          this.nameval = emp.empName;
          this.salval = emp.empSal;
          this.depval = emp.empDep;
      }
          this.i=x;
      }
      x++;
    }
  
 delete_detail(EmpId:string) {
 
    var i=0;

    for(var emp of this.employees){
      i++;
      if(emp.empId==EmpId){
        this.employees.splice(i-1,1);
      }
    }
 }
 onChangeData(EmpId:string,EmpName:string,EmpSal:string,EmpDep:string){
    this.employees[this.i].empId=EmpId;
    this.employees[this.i].empName=EmpName;
    this.employees[this.i].empSal=EmpSal;
    this.employees[this.i].empDep=EmpDep;
  }
}