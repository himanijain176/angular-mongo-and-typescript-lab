import { Component,OnInit } from '@angular/core';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { SearchPipe } from './search.pipe';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  booklist:any[];
  id:number;
  title:string;
  author:string;
  year:number;
  file='./assets/booklist.json';
  constructor(private h:HttpClient){
    
  }

  ngOnInit(){
    this.h.get(this.file).subscribe(data=>{
      this.booklist=data as string[];
    }
    );
  }
}
