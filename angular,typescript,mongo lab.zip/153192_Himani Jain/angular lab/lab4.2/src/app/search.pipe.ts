import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(list: any[],id:number,title:string,author:string,year:number): any {
   
    if(id!=null){
      let s:string=id.toString();
      return list.filter((i)=>{
          return i.id.toString().includes(s);
      })
    }
    else if(title!=null){
      return list.filter((i)=>{
          return i.title.includes(title);
      })
    }
    else if(author!=null){
      return list.filter((i)=>{
          return i.author.includes(author);
      })
    }
    else if(year!=null){
      let s:string=year.toString();
      return list.filter((i)=>{
          return i.year.toString().includes(s);
      })
    }
    else
      return list;
  }

}
