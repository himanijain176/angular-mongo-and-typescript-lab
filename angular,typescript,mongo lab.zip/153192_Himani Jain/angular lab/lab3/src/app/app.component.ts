import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  Cat = ["Grocery", "Mobile", "Electronics", "Clothes"];
  Stores = ["Big Bazar", "DMart", "Reliance", "Mega Store"];
  submitClicked:boolean = false;
  productForm: FormGroup;
  productId: FormControl;
  productName: FormControl;
  productCost: FormControl;
  productCat: FormControl;
  productOnline: FormControl;
  inStore: FormGroup;

  createControls() {
    this.productId = new FormControl('', Validators.required);
    this.productName = new FormControl('', [Validators.required,
    Validators.pattern('[a-zA-Z]{1,}')
    ]);
    this.productCost = new FormControl('', [Validators.required,
    Validators.min(1)
    ]);
    this.productCat = new FormControl('', Validators.required);
    this.productOnline = new FormControl('', Validators.required);
    this.inStore = new FormGroup({}, (formGroup: FormGroup) => { return this.check(formGroup); });
    for (let s of this.Stores) {
      let control: FormControl = new FormControl(false, Validators.required);
      this.inStore.addControl(s, control);
    }
  }

  createForm() {
    this.productForm = new FormGroup({
      id: this.productId,
      name: this.productName,
      cost: this.productCost,
      cat: this.productCat,
      online: this.productOnline,
      store: this.inStore
    });
  }

  ngOnInit() {
    this.createControls();
    this.createForm();

  }

  check(formGroup: FormGroup) {
    for (let key in formGroup.controls) {
      if (formGroup.controls.hasOwnProperty(key)) {
        let control: FormControl = <FormControl>formGroup.controls[key];
        if (control.value == true) {
          return null;
        }
      }
    }
    return {
      validateStore: {
        valid: false
      }
    };
  }

  checkInHTML(formGroup: FormGroup) {
    for (let key in formGroup.controls) {
      if (formGroup.controls.hasOwnProperty(key)) {
        let control: FormControl = <FormControl>formGroup.controls[key];
        if (control.value == true) {
          return true;
        }
      }
    }
    return false;
  }

  onSubmit() {
    this.submitClicked=true;
    if (this.productForm.valid) {
      alert("Form Submitted!");
      console.log(this.productForm.value);
      this.productForm.reset();
      this.submitClicked=false;
    }
    else {
      
    }
  }

}
