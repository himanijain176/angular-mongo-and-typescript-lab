import {Mobile} from './Mobile';

export class BasicPhone extends Mobile{
	constructor(id:number,name:string,cost:number,private type:string){
		super(id,name,cost);
	
	}
	printMobileDetail()
	{
	super.printMobileDetail();
	console.log("mobile type is: "+this.type);
	}
}
