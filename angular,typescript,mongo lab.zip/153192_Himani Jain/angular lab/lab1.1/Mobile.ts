export class Mobile{
	constructor(private id:number,private name:string,private cost:number)
	{
	}
	printMobileDetail()
	{
		console.log("Mobile Id : "+this.id);
		console.log("Mobile name: "+this.name); 
		console.log("Mobile Cost : "+this.cost); 
		
	}
}
