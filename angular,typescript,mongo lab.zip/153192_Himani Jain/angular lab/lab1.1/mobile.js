"use strict";
exports.__esModule = true;
var Mobile = /** @class */ (function () {
    function Mobile(id, name, cost) {
        this.id = id;
        this.name = name;
        this.cost = cost;
    }
    Mobile.prototype.printMobileDetail = function () {
        console.log("Mobile Id : " + this.id);
        console.log("Mobile name: " + this.name);
        console.log("Mobile Cost : " + this.cost);
    };
    return Mobile;
}());
exports.Mobile = Mobile;
