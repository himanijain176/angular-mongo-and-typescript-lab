import {SmartPhone} from './SmartPhone';
import {BasicPhone} from './BasicPhone';
		
		var mobile1=new BasicPhone(19278,"Nokia 110",1000.50,"Basic Phone");
			var mobile2=new SmartPhone(19784,"Samsung Galaxy 7",15070.50,"Smart Phone");
			mobile1.printMobileDetail();
			mobile2.printMobileDetail();
		