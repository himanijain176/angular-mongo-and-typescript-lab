"use strict";
exports.__esModule = true;
var SmartPhone_1 = require("./SmartPhone");
var BasicPhone_1 = require("./BasicPhone");
var mobile1 = new BasicPhone_1.BasicPhone(19278, "Nokia 110", 1000.50, "Basic Phone");
var mobile2 = new SmartPhone_1.SmartPhone(19784, "Samsung Galaxy 7", 15070.50, "Smart Phone");
mobile1.printMobileDetail();
mobile2.printMobileDetail();
