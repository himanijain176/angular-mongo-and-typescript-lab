import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  public employees = [
    {"empId":10010,"empName":"Rahul","empSal":9000,"empDep":"JAVA","empjoiningData":"6/12/2014"},
    {"empId":1002,"empName":"Vikash","empSal":11000,"empDep":"ORAAPS","empjoiningData":"6/12/2017"},
    {"empId":1003,"empName":"uma","empSal":12000,"empDep":"JAVA","empjoiningData":"6/12/2010"},
    {"empId":1004,"empName":"Sachin","empSal":11500,"empDep":"ORAAPS","empjoiningData":"11/12/2017"},
    {"empId":1005,"empName":"Amol","empSal":7000,"empDep":".NET","empjoiningData":"1/1/2018"},
    {"empId":1006,"empName":"Vishal","empSal":17000,"empDep":"BI","empjoiningData":"9/12/2012"},
    {"empId":1007,"empName":"Rajita","empSal":21000,"empDep":"BI","empjoiningData":"6/7/2014"}
  ]

  SortByid()
  {
 this.employees.sort((a,b)=>{
   return a.empId-b.empId;
 })
    }

  SortByname()
  { 
     this.employees.sort((a,b)=>{
    if(a.empName>b.empName)
        return 1;
   else if(a.empName<b.empName)
      return -1;  
  else
    return 0;
  })
  }

    SortBysalary()
    {
      this.employees.sort((a,b)=>{
      return a.empSal-b.empSal;
    })
    }

    SortBydepartment()
    {
    this.employees.sort((a,b)=>{
    if(a.empDep>b.empDep)
        return 1;
   else if(a.empDep<b.empDep)
      return -1;  
  else
    return 0;
  })
    }
  }

