import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 id:number;
 name:string;
 sal:number;
 dep:string;
constructor(){}
display():void
{
 alert(" "+this.id+" "+this.name+" "+this.sal+" "+this.dep);
}
}
