import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'JSON to Table Example';
   booklistdata: any [];
   
  constructor (private httpService: HttpClient) { }
 

  ngOnInit () {
    this.httpService.get('./assets/booklist.json').subscribe(
      data => {
        this.booklistdata = data as string [];	 // FILL THE ARRAY WITH DATA.
      
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }
}
